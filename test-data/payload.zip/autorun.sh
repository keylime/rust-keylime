#!/bin/sh

test -n "$KEYLIME_TEST_DIR" || exit 1

date > "$KEYLIME_TEST_DIR/timestamp"
